#ifndef EXECUTER_HPP
#define EXECUTER_HPP

#include "lex.hpp"

#include <vector>

class Executer {
public:
    void execute(std::vector<Lex>& poliz);
};

#endif