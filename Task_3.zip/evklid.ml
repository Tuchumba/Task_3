program
var nod:int, data : record a,b:int, filled:bool;;
begin
    data.filled := false;
        read(data.a);
        read(data.b);
    data.filled := true;
    while data.b != 0 do
    begin
        if data.a > data.b then
            data.a := data.a - data.b
        else
            data.b := data.b - data.a
    end;
    nod := data.a;
    write(nod)
end@